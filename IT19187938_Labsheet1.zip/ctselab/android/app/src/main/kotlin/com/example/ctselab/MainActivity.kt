package com.example.ctselab

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
